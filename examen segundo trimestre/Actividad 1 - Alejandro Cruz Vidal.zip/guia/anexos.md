# Anexos

Documentos específicos vinculados a determinados requisitos funcionales o
técnicos ("prueba del seis" y similares).

Poner cada uno en un apartado separado, indicando en el título de cada apartado
el código y la descripción corta del requisito asociado (por ejemplo,
**(RF24) Prueba del seis**).
