# Diagramas

## Diagramas de clases

Incluir.

## Diagramas de estructura lógica de datos

Incluir.
