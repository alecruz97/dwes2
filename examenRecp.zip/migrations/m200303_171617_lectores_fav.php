<?php

use yii\db\Migration;

/**
 * Class m200303_171617_lectores_fav
 */
class m200303_171617_lectores_fav extends Migration
{
    /**
     * {@inheritdoc}
     */
    public function safeUp()
    {
        $this->createTable('{{%favoritos}}', [
            'id' => $this->primaryKey(),
            'libro_id' => $this->bigInteger()->notNull(),
            'lector_id' => $this->bigInteger()->notNull(),
        ]);

        $this->addForeignKey(
            'fk_favoritos_lectores',
            'favoritos',
            'lector_id',
            'lectores',
            'id'
        );

        $this->addForeignKey(
            'fk_favoritos_libros',
            'favoritos',
            'libro_id',
            'libros',
            'id'
        );
    }

    /**
     * {@inheritdoc}
     */
    public function safeDown()
    {
        $this->dropForeignKey('fk_favoritos_libros', 'favoritos');
        $this->dropForeignKey('fk_favoritos_lectores', 'favoritos');
        $this->dropTable('favoritos');
    }

    /*
    // Use up()/down() to run migration code without a transaction.
    public function up()
    {

    }

    public function down()
    {
        echo "m200303_171617_lectores_fav cannot be reverted.\n";

        return false;
    }
    */
}
