# Decisiones adoptadas

Explicar, indicando en cada caso su justificación.
