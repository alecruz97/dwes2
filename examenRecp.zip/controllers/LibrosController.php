<?php

namespace app\controllers;

use app\models\Favoritos;
use app\models\ImagenForm;
use app\models\Libros;
use app\models\LibrosSearch;
use Yii;
use yii\filters\AccessControl;
use yii\filters\VerbFilter;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\web\UploadedFile;

/**
 * LibrosController implements the CRUD actions for Libros model.
 */
class LibrosController extends Controller
{
    /**
     * {@inheritdoc}
     */
    public function behaviors()
    {
        return [
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'delete' => ['POST'],
                ],
            ],
            // 'access' => [
            //     'class' => AccessControl::class,
            //     'only' => ['index'],
            //     'rules' => [
            //         [
            //             'allow' => true,
            //             'actions' => ['index', 'update'],
            //             'roles' => ['@'],
            //             'matchCallback' => function ($rules, $action) {
            //                 return Yii::$app->user->identity->nombre === 'manolo';
            //             },
            //         ],
            //         [
            //             'allow' => true,
            //             'actions' => ['view', 'delete'],
            //             'roles' => ['@'],
            //             'matchCallback' => function ($rules, $action) {
            //                 return Yii::$app->user->identity->nombre === 'pepe';
            //             },
            //         ],
            //     ],
            // ],
        ];
    }

    /**
     * Lists all Libros models.
     * @return mixed
     */
    public function actionIndex()
    {
        $searchModel = new LibrosSearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);

        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
        ]);
    }

    /**
     * Displays a single Libros model.
     * @param int $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionView($id)
    {
        return $this->render('view', [
            'model' => $this->findModel($id),
        ]);
    }

    /**
     * Creates a new Libros model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */
    public function actionCreate()
    {
        $model = new Libros();

        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            return $this->redirect(['view', 'id' => $model->id]);
        }

        return $this->render('create', [
            'model' => $model,
        ]);
    }

    public function actionCorreo()
    {
        Yii::$app->mailer->compose()
            ->setFrom(Yii::$app->params['smtpUsername'])
            ->setTo('Vulaced38@einrot.com')
            ->setSubject('Este es el asunto del mensaje')
            ->setTextBody('Este es el cuerpo del mensaje')
            ->send();
    }

    public function actionImagen($id)
    {
        $model = new ImagenForm();

        if (Yii::$app->request->isPost) {
            $model->imagen = UploadedFile::getInstance($model, 'imagen');
            if ($model->upload($id)) {
                return $this->redirect('libros/index');
            }
        }

        return $this->render('imagen', [
            'model' => $model,
        ]);
    }

    /**
     * Updates an existing Libros model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param int $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionUpdate($id)
    {
        $model = $this->findModel($id);

        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            return $this->redirect(['view', 'id' => $model->id]);
        }

        return $this->render('update', [
            'model' => $model,
        ]);
    }

    /**
     * Deletes an existing Libros model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param int $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionDelete($id)
    {
        $this->findModel($id)->delete();

        return $this->redirect(['index']);
    }
    
    public function actionFavoritos()
    {
        $model = $this->find();
        if (!isset(Yii::$app->session->id)) {
            return $this->redirect(['site/login']);
        } else if (!($model->getFavoritos(Yii::$app->user->id)->exists())) {
            return $this->redirect(['usuario/update']);
        }

        return $this->render('view', [
            'model' => $model->getFavLectores(),
        ]);

    }

    /**
     * Finds the Libros model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param int $id
     * @return Libros the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id)
    {
        if (($model = Libros::findOne($id)) !== null) {
            return $model;
        }

        throw new NotFoundHttpException('The requested page does not exist.');
    }

   
}
