# Dificultades encontradas

Explicar, indicando también las soluciones adoptadas en cada caso.

Incluir aquí el elemento de innovación que se indicó en la propuesta.
