<?php

namespace app\components;

interface IDos
{
    
}
