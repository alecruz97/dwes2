<?php

namespace app\controllers;

class ProvinciasController extends \yii\web\Controller
{
    public function actionIndex()
    {
        return $this->render('index');
    }

}
