# Descripción general del proyecto

Explicar.

## Funcionalidad principal de la aplicación

Explicar.

## Objetivos generales

A diferencia de los casos de uso, los objetivos no tienen principio ni fin.

Por ejemplo:

* Objetivo: "gestionar los alquileres y las devoluciones de las películas".
* Casos de uso: "alquilar una película", "devolver una película".

## URL del repositorio

[https://github.com/ricpelo/proyecto](https://github.com/ricpelo/proyecto)

## URL de la documentación

[https://ricpelo.github.io/proyecto](https://ricpelo.github.io/proyecto)
