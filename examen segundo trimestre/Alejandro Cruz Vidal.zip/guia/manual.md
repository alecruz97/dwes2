# Manual de usuario

Explicar, incluyendo capturas de pantalla.
