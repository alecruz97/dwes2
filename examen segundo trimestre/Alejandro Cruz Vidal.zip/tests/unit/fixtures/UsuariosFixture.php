<?php

namespace tests\unit\fixtures;

use yii\test\ActiveFixture;

class UsuariosFixture extends ActiveFixture
{
    public $modelClass = 'app\models\Usuarios';
}
