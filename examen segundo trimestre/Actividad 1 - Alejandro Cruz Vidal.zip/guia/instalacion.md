# Instrucciones de instalación y despliegue

## En local

Explicar.

## En la nube

Explicar.
