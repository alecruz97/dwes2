<?php

use yii\bootstrap4\Html;
use yii\widgets\DetailView;

/* @var $this yii\web\View */
/* @var $model app\models\Libros */

$this->title = $model->id;
$this->params['breadcrumbs'][] = ['label' => 'Libros', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
\yii\web\YiiAsset::register($this);
$js = <<<EOT
$('#citas-especialidad_id').on('change', function (ev) {
    $.ajax({
        method: 'GET',
        url: '$url',
        data: {
            especialidad_id: especialidad_id
        },
        success: function (data, code, jqXHR) {
            var sel = $('#citas-especialista_id');
            sel.empty();
            for (var i in data) {
                sel.append(`<option value="\${i}">\${data[i]}</option>`);
            }
            $('#citas-especialista_id').trigger('change');
        }   
    });
});
$('#citas-especialista_id').on('change', function (ev) {
    var el = $(this);
    var especialista_id = el.val();
    $.ajax({
        method: 'GET',
        url: '$urlHueco',
        data: {
            especialista_id: especialista_id
        },
        success: function (data, code, jqXHR) {
            $('#citas-instante').val(data.formateado);
            $('#citas-instante-oculto').val(data.valor);
            $('#citas-create').yiiActiveForm('validate');
            $('#citas-create').yiiActiveForm('validateAttribute', 'citas-especialista_id');
            $('#citas-create').yiiActiveForm('validateAttribute', 'citas-instante');
        }
    });
});
EOT;
$this->registerJs($js);
?>
<div class="libros-view">

    <h1><?= Html::encode($this->title) ?></h1>

    <p>
        <?= Html::a('Update', ['update', 'id' => $model->id], ['class' => 'btn btn-primary']) ?>
        <?= Html::a('Delete', ['delete', 'id' => $model->id], [
            'class' => 'btn btn-danger',
            'data' => [
                'confirm' => 'Are you sure you want to delete this item?',
                'method' => 'post',
            ],
        ]) ?>
    </p>

    <?= DetailView::widget([
        'model' => $model,
        'attributes' => [
            'isbn',
            'titulo',
            'num_pags',
            'genero.denom',
            'created_at:datetime',
            'fav',
            [
                'attribute' => 'favorito',
                'format' => 'html',
                'value' => function ($model, $url, $index, $key) {
                    return Html::button();
                },

            ],
            [
                'attribute' => 'imagen',
                'value' => function ($model, $widget) {
                    return Html::img($model->imagenUrl, ['width' => 400]);
                },
                'format' => 'raw',
            ],
        ],
    ]) ?>

</div>
