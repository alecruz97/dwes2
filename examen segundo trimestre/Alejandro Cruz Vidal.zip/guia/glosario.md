# Glosario de términos

Indicar y definir uno por uno.
