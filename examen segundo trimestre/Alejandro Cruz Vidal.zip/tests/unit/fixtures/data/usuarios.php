<?php

return [
    [
        'nombre' => 'vaca.roberto',
        'password' => '$2y$13$AbFTOYb9VlhAT9B5HsTIh.EyojYnHPlXkJBB/ifYg6F/sHa/9SvKS',
        'auth_key' => 'SuZOf8aEastmBX_AQyWNsvAeFqgwoTDY',
        'telefono' => '980-018583',
        'poblacion' => 'A Alfaro',
    ],
    [
        'nombre' => 'alberto19',
        'password' => '$2y$13$H/Xzfudn7XZT2jGQN.bXdOXuIme96o7tc89Hdky7u11d1AUtHZ4bi',
        'auth_key' => '5UXD-aFyEJbJi8eeRhMf8hV0VaMnGZ4r',
        'telefono' => '+34 693 834368',
        'poblacion' => 'San Domínguez',
    ],
    [
        'nombre' => 'mespinosa',
        'password' => '$2y$13$YppbMuFIlG6joh2IcNIAY.nX.9Dt7efZLtcCs8dG5ruNK8KGLJ0Ne',
        'auth_key' => '-TCsEeW4ivD6nSX5h3dydJbi75q42a0V',
        'telefono' => '+34 652-929710',
        'poblacion' => 'Villa Barrios de Lemos',
    ],
    [
        'nombre' => 'mara.caballero',
        'password' => '$2y$13$alqQs15drCLRRGIpv572iOC1i4gAF3Hi5BgrMEaHgqBpsMMu9hyeS',
        'auth_key' => 'qNSFfbSc25NJa0G3gQC6y_OBfSOCFojN',
        'telefono' => '965-49-1015',
        'poblacion' => 'San Cárdenas',
    ],
    [
        'nombre' => 'vila.miriam',
        'password' => '$2y$13$H7SJdO6VFNmlmNQWJZzebeZq.xUgTf41S/2/PqfUrL3V.2VlWyawq',
        'auth_key' => '7xKI0iU_8_ThBKNlF6vwz13o2M-320_y',
        'telefono' => '954-813387',
        'poblacion' => 'Urías del Vallès',
    ],
    [
        'nombre' => 'rordonez',
        'password' => '$2y$13$AVfOlfZXHQTdcLqG42QrOeaCjybEQQ6s4JPiFq8yXr9vZDKvAhu8u',
        'auth_key' => 'hOy8vfmrUMcpYpzcozf4ITEdxCTbCdHG',
        'telefono' => '682850032',
        'poblacion' => 'Villa Batista del Pozo',
    ],
    [
        'nombre' => 'zbeltran',
        'password' => '$2y$13$A12aWYGMjPj9vO8WfrCV3ul7w6CeMj37OklpnWvaGnsWSJSLSr126',
        'auth_key' => 'zYW6uQKRuxUNuD-WUf1wNXVUZFdF-tM6',
        'telefono' => '669-583319',
        'poblacion' => 'O Jaimes de Ulla',
    ],
    [
        'nombre' => 'cristina.rodarte',
        'password' => '$2y$13$mN.JV29TF3iibmUK3fDglO409qTY3i0RYHrf2tBxN2rqXNMGa60DC',
        'auth_key' => 'UT0JHlazUiRAU5iR_RuRiOBy17tsoxmH',
        'telefono' => '900 95 6431',
        'poblacion' => 'Os Guevara',
    ],
    [
        'nombre' => 'wgalindo',
        'password' => '$2y$13$.bFTow12e8tqpIZRfG/qseimzrrGvI2uOggeiNM.mMnxSVKKEMJNO',
        'auth_key' => 'vivNA8VNLN7N30a8NUJh6nZxmy7E9TWm',
        'telefono' => '919 23 5328',
        'poblacion' => 'El Castellanos',
    ],
    [
        'nombre' => 'godinez.sofia',
        'password' => '$2y$13$YqN8iRvkEPIbrYB0a4pJ3OyYQrNhhajnBYvSis1862lP4luSXQW6C',
        'auth_key' => '5vWzlzdWZXoJ8-va7V761wIQO4QWxdlj',
        'telefono' => '666-069726',
        'poblacion' => 'Los Palacios Medio',
    ],
];
