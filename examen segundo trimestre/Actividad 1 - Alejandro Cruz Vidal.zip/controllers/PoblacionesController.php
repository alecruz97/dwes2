<?php

namespace app\controllers;

class PoblacionesController extends \yii\web\Controller
{
    public function actionIndex()
    {
        return $this->render('index');
    }

}
